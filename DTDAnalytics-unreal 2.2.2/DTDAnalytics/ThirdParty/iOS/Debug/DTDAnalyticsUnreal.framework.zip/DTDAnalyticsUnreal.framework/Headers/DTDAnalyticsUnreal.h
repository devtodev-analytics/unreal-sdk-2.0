//
// Copyright devtodev (c) 2020.
// All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for iOSUnreal.
FOUNDATION_EXPORT double DTDAnalyticsUnrealVersionNumber;

//! Project version string for iOSUnreal.
FOUNDATION_EXPORT const unsigned char DTDAnalyticsUnrealVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <iOSUnreal/PublicHeader.h>
